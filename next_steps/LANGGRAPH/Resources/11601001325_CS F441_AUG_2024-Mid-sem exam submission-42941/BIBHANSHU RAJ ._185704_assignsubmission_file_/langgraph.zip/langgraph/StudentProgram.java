
import java.util.Scanner;

public class StudentProgram {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String input = sc.next();
        System.out.println("You entered: " + input);
    }
}
